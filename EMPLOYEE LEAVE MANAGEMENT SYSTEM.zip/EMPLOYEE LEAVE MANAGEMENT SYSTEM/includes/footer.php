<footer>
        <div class="footer-area">
                <p>©Copyright-<?php echo date("Y");?> | Employee Leave Management System | Developed By ELMS</a></p>
        </div>
</footer>
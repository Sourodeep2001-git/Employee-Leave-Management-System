<footer>
        <div class="footer-area">
                <p>©Copyright-<?php echo date("Y");?> | Developed By ELMS </a></p>
                <p> Email: elms@mail.com</p>
                
        </div>
</footer>